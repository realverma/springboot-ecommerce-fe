import React from 'react'

const MerchantView = () => {
  return (
    <div>MerchantView</div>
  )
}

export default MerchantView